#include "mem.h"




void kmemset(void *p, char c, int n)
{
	char *v= (char*)p;
	int i;
	for(i=0;i<n;i++)
		v[i]=c;
		
}

void kmemcpy(void* dv,const void* sv,unsigned n)
{
	char *d = (char*)dv;
	const char *s = (const char*)sv;
	while(n--)
		*d++ = *s++;
}

void cmemset(void *p, short c, int n)
{
	short *v= (short*)p;
	int i;
	for(i=0;i<n;i++)
		v[i]=c;
		
}

void outb(unsigned short port, unsigned char value)
{
	asm volatile("out dx,al"
		:
		:"a"(value), "d"(port)
		:"memory"
		);
}


void outw(unsigned short port, unsigned short value)
{
	asm volatile("out dx,ax"
		:
		:"a"(value), "d"(port)
		:"memory"
		);
}

unsigned char inb(unsigned short port)
{
	unsigned value;
	asm volatile("in al,dx" : "=a"(value):"d"(port) );
	return (unsigned char) value;
}

unsigned short inw(unsigned short port)
{
	unsigned value;
	asm volatile("in ax,dx" : "=a"(value):"d"(port) );
	return (unsigned short) value;
}