#include "Multiboot.h"
#include "console.h"
#include "testsuite.h"
#include "mem.h"
#include "disk.h"

/*int factorialFunc(int fact)
{
	if (fact >= 1)
        return fact*factorialFunc(fact-1);
    else
        return 1;
}
*/

void clearBss(char* bssStart, char* bssEnd)
{
	while (bssStart != bssEnd) 
	{
        *bssStart = 0;
        bssStart++;
    }
}

void kmain(struct MultibootInfo* mbi)
{
	//int index1,index2;
	console_init(mbi);
	initsupb();
	sweet();
	
	/*while(1)
	{
		asm volatile ("mov esi, 0xf00d\n""hlt"::: "memory");
	}*/
	
	/*
	int c,d;
	int red = 255;
	int green = 1;
	int blue = 0;
	
	int redBool = 1;
	int greenBool = 1;
	int blueBool = 0;
	while(1)
	{
		draw_line(60,30,60,75,red,green,blue);
		draw_line(95,30,135,30,red,green,blue);
		draw_line(95,30,95,50,red,green,blue);
		draw_line(95,50,135,50,red,green,blue);
		draw_line(135,50,135,70,red,green,blue);
		draw_line(95,70,135,70,red,green,blue);
		draw_line(40,30,80,30,red,green,blue);
		
		if(redBool && red != 255 && red != 0)
			red++;
		
		if(greenBool && green != 255 && green != 0)
			green++;
	
		if(blueBool && blue != 255 && blue != 0)
			blue++;
		
		if(green == 255 && red <= 255 && blue == 0)//yellow
		{
			red--;
			redBool = 0;
		}
		if(green <= 255 && blue == 255 && red == 0)
		{
			green--;
			greenBool = 0;
		}
		if(green == 0 && blue <= 255 && red == 255)//purple
		{
			blue--;
			blueBool = 0;
		}
		if(green == 255 && blue == 0 && red == 0)//green
		{
			blueBool = 1;
			blue = 1;
		}
		if(green == 0 && blue == 255 && red ==0)//blue
		{
			redBool = 1;
			red = 1;
		}
		if(green == 0 && blue == 0 && red ==255)//red
		{
			greenBool = 1;
			green = 1;
		}
		
		
		
		for (c = 1; c <= 1767; c++)
		for (d = 1; d <= 767; d++)
		{}
	}*/
	//factorialFunc(6);
	
}



