#include "kprintf.h"
#include "disk.h"
#include "mem.h"

int isBusy()
{
	return inb(0x1f7) & 0x80;
}

char  buffer[4096];
struct Inode ino;
struct Superblock supb;
struct DirEntry* d;
char buffboi[BLOCK_SIZE];

unsigned get_file_inode(unsigned dir_inode, const char* filename)
{
	
	
	return 0;

}

void initsupb()
{
	disk_read_sector(2, &supb);
    disk_read_sector(3, ((char*)&supb) + 512);
}

int disk_read_block(unsigned num, void* datablock)
{
    unsigned sector = num * 8;
    for(int i = 0; i < 8; ++i)
    {
        if(disk_read_sector(sector, datablock + (i * 512)) < 0)
			return -1;
        ++sector;
    }
    return 0;

}


int disk_read_sector(unsigned sector, void* datablock)
{
	while(isBusy())
		;
	//initiate a read
	outb(0x1f6,0xe0 | (sector >> 24 ));//selecting device
	outb(0x3f6,2);//turn off interrupts
	outb(0x1f2,1);
	outb(0x1f3, sector);//low 8 bits
	outb(0x1f4, sector >> 8); 
	outb(0x1f5, sector >> 16);
	
	
	outb(0x1f7,0x20);
	while(1)
	{
		while(isBusy())
		;
		if((inb(0x1f7) & 0x08))
		{
			break;
		}
		else if((inb(0x1f7) & 0x01) || (inb(0x1f7) & 0x20))
		{
			return -1;
		}
	}
	
	unsigned short* dblock = (unsigned short*) datablock;
	for(int i=0;i<256;++i)
	{
 		unsigned short d = inw(0x1f0);
		*dblock = d;
		dblock++;
	}

	
	return 0;
}



int disk_read_inode(unsigned num, struct Inode* ino)
{	
	int inodesPerBlock = BLOCK_SIZE / sizeof(struct Inode);	
	int group = (num-1)/supb.inodes_per_group;		
	int inodeTableStartingBlock = supb.blocks_per_group * group + 4;	
	int inodesFromTableStart = (num - 1)% inodesPerBlock;	
	int bytesFromTableStart = inodesFromTableStart * sizeof(struct Inode);	
	int blocksFromTableStart = bytesFromTableStart / BLOCK_SIZE;	
	int block = inodeTableStartingBlock + blocksFromTableStart;	
	int inodesToSkipOver = inodesFromTableStart % inodesPerBlock;
	
	disk_read_block( block , buffboi);
	kmemcpy( ino, buffboi + inodesToSkipOver * sizeof(struct Inode) , sizeof(struct Inode) );
	return 0;
}
	


int list_directory(int dir_inode, int indent)
{	
	if(dir_inode == 0)
	{
		disk_read_block( 4, buffer );
		ino = ((struct Inode*) buffer)[1];
		dir_inode++;
	}
	
	disk_read_block(ino.direct[0],buffer);
	char* c  = buffer;
	
	
	while(1)
	{
		d = (struct DirEntry*) c;
		if(d->rec_len == 0)
			break;
		for(int tab = 0; tab < indent; tab++)
		{
			kprintf("\t");
		}
		kprintf("%hu ",d->inode);
		for(int i = 0; i < d->name_len; i++)
		{
			kprintf("%c",d->name[i]);
			
		}
		kprintf("\n");
		
		disk_read_inode(d->inode, &ino);
		
		if(ino.mode >> 12 == 4 && d->name[1] != '.' && d->name[0] != '.')
		{		
			static char tempc[BLOCK_SIZE];	
			for(int ind = 0; ind < BLOCK_SIZE; ind++)
			{
				tempc[ind] = c[ind];				
			}
			list_directory(dir_inode, indent + 1);
			c = tempc;
			d =(struct DirEntry*) c;
		}				
		
		
		c +=  d->rec_len;
	}
	
	d = (struct DirEntry*)c;
	
	return 0;
}
	

int disk_write_sector(unsigned sector, const void* datablock)
{
	while(isBusy())
		;
	short* p = (short*)datablock;//...data to write...
	
	outb(0x1f6,0xe0 | (sector >> 24 ));//selecting device
	outb(0x3f6,2);//turn off interrupts
	outb(0x1f2,1);
	outb(0x1f3, sector);//low 8 bits
	outb(0x1f4, sector >> 8);// next 8
	outb(0x1f5, sector >> 16);//next 8
	
	
	outb(0x1f7,0x30);
	while(1)
	{
		while(isBusy())
		;
		if((inb(0x1f7) & 0x08))
			break;
		else if((inb(0x1f7) & 0x01) || (inb(0x1f7) & 0x20))
			return -1;
		
	}
	
	for(int i=0;i<256;++i)
	{
		outw( 0x1f0, *p );
		p++;
	}
	outb(0x1f7,0xe7);
	return 0;
}


















