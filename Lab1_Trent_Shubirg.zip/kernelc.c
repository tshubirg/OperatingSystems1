int factorialFunc(int fact)
{
	if (fact >= 1)
        return fact*factorialFunc(fact-1);
    else
        return 1;
}

void clearBss(char* bssStart, char* bssEnd)
{
	while (bssStart != bssEnd) 
	{
        *bssStart = 0;
        bssStart++;
    }
}

void kmain()
{
	factorialFunc(5);
	asm volatile ("mov esi, 0xf00d\n""hlt"::: "memory");
	

}



