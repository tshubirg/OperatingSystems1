#pragma once

#define va_start(v,l) v.x=((char*)l)+sizeof(l)

#define va_arg(v,t) (*((*t)_va_arg(&v,sizeof(t))))

#define va_end(x) 

char* _va_arg(va_list *v, unsigned size)
{
	char * temp = v->x;
	v ->x+=size;
	return tmp;


typedef struct va_list_
{
	
}va_list;