#include "console.h"

int mRow = 0;
int mCol = 0;
int backbool = 0;
int rowMask = 16;
int key = 0;
int colMask = 10;

void console_init(struct MultibootInfo* mbi)
{
	framebuffer = (volatile unsigned char*) (unsigned) mbi->mbiFramebufferAddress;
	multi = mbi;
}

void draw_line(int x1, int y1,int x2,int y2, int r, int g, int b)
{
	int index1,index2;
	
	if(x1 == x2)
	{
		index1 = x1;
		for(index2 = y1; index2 < y2; index2++)
		{
			set_pixel(index1,index2,r,g,b);
		}
	}
	else if(y1 == y2)
	{
		index2 = y1;
		for(index1 = x1; index1 < x2; index1++)
		{
			set_pixel(index1,index2,r,g,b);
		}
	}
}

void set_pixel(int x, int y, int r, int g, int b)
{
	volatile unsigned char* temp = framebuffer;
	temp = framebuffer+(2*x+(y*multi->mbiFramebufferPitch));
	 r >>= (8-multi->mbiFramebufferRedMask); 
	 g >>= (8-multi->mbiFramebufferGreenMask); 
	 b >>= (8-multi->mbiFramebufferBlueMask);
	
	unsigned short colorValue = (b<<multi->mbiFramebufferBluePos) | (g<<multi->mbiFramebufferGreenPos) | (r<<multi->mbiFramebufferRedPos);
	
	*(unsigned short*)temp = colorValue;
	
	
}


void draw_character(int x, int y, unsigned char ch)
{
	int *C = (int*)font_data[ch];
	int cy,cx;


	for(cy=0; cy<CHAR_HEIGHT; ++cy)
	{
		for(cx=0;cx<CHAR_WIDTH;++cx)//cx=CHAR_WIDTH-1; cx>0; --cx
		{
			if((MASK_VALUE>>cx)&C[cy])
				set_pixel(cx+x,cy+y,255,150,0);
			else
				set_pixel(cx+x,cy+y,0,0,0);
		}
	}

}

void overstrike(int x, int y, unsigned char ch)
{
	int *C = (int*)font_data[ch];
	int cy,cx;


	for(cy=0; cy<CHAR_HEIGHT; ++cy)
	{
		for(cx=0;cx<CHAR_WIDTH;++cx)//cx=CHAR_WIDTH-1; cx>0; --cx
		{
			if((MASK_VALUE>>cx)&C[cy])
				set_pixel(cx+x,cy+y,255,150,0);
			
		}
	}

}

void console_putc(const char s)
{
	int inX,inY;
	
	if(s == '\f')
	{
		for(inX = 0; inX<800; inX++)
		{
			for(inY = 0; inY<800;inY++)
			{
				set_pixel(inX,inY,0,0,0);
			}
		}
		mRow = 0;
		mCol = 0;
		return;
	}
	else if(s == '\t')
	{
		if((mCol) % 80 == 0)
		{
			mCol += 80;
		}
		else
		{
			while((mCol) % 80)
			{
				
				
					mCol+=1;
				
			}
			if(mCol >= 800)
				{
					mCol = 0;
					mRow += rowMask;
				}
			
		}
		return;
		
	}
	else if(s == '\n')
	{
		mCol = 0;
		mRow += rowMask;
		return;
	}
	else if(s == '\x7f')
	{
		if(mCol == 0)
		{
			mCol = 800-colMask;
			mRow -= rowMask;
		}
		else
			mCol -= colMask;
		draw_character(mCol,mRow,' ');
		return;
	}
	else if(s == '\r')
	{
		mCol = 0;
		return;
	}
	else if(s == '\b')
	{
		backbool =1;
		if(mCol == 0)
		{
			mCol = 800-colMask;
			mRow -= rowMask;
		}
		else
			mCol -= colMask;
		
		return;
	}
	else
	{
		draw_character(mCol,mRow,s);
		
	}
	if(backbool && key == s)
	{
		overstrike(mCol+1,mRow,s);
		backbool = 0;
		key = 0;
		
	}
	mCol += colMask;
	key = s;
	
	if(mCol == 800)
	{
		mCol = 0;
		mRow += rowMask;
	}
	
}

void draw_string(int x, int y, const char* s)
{
	int tempX,tempY;
	tempX = x;
	tempY = y;
	const char* index;
	for(index=&s[0]; *index != '\0'; index++)
	{
		draw_character(tempX,tempY,*index);
		tempX += 10;
	}
}












