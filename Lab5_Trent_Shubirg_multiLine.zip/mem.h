#pragma once

void kmemset(void *p, char c, int n);
void cmemset(void *p, short c, int n);