#include "mem.h"




void kmemset(void *p, char c, int n)
{
	char *v= (char*)p;
	int i;
	for(i-0;i<n;i++)
		v[i]=c;
		
}


void cmemset(void *p, short c, int n)
{
	short *v= (short*)p;
	int i;
	for(i-0;i<n;i++)
		v[i]=c;
		
}