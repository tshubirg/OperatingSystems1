
#pragma once

int file_close(int fd);
int file_open(const char* filename, int flags);
int file_write(int fd, const void* buffer, int count);
int file_read(int fd, void* buf, int count);
int file_seek(int fd, int offs, int whence);
void init_file_table();