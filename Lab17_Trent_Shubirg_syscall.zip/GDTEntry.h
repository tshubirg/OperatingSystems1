#pragma pack(push,1)
struct GDTEntry{
	unsigned short limitLow;
	unsigned char base0, base1, base2;
	unsigned short flagsAndLimitHigh;
	unsigned char base3;
};
#pragma pack(pop)
