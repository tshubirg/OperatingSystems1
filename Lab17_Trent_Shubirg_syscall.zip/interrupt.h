#pragma once
#pragma pack(push,1)
struct InterruptFrame{
	unsigned eip;
	unsigned cs;
	unsigned eflags;
	unsigned esp; //only used when undergoing
	unsigned ss; //a ring transition
};
#pragma pack(pop)


#pragma pack(push,1)
struct LIDT{
	unsigned short size;
	struct IDTEntry* addr;
};
#pragma pack(pop)

#include "syscalls.h"

void interrupt_init();
void divideByZero(struct InterruptFrame* fr);
void debugTrap(struct InterruptFrame* fr);
void undefinedOpcode(struct InterruptFrame* fr);
void protectionFault(struct InterruptFrame* fr, unsigned code);
void pageFault(struct InterruptFrame* fr, unsigned code);
void unknownInterrupt(struct InterruptFrame* fr);
void exec(const char* filename);
void syscallInterrupt(struct InterruptFrame* fr);
void  syscall_handler ( unsigned* ptr );
//int syscall(int p0, int p1, int p2, int p3);