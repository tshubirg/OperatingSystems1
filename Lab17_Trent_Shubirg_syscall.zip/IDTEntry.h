#pragma pack(push,1)
struct IDTEntry{
	unsigned short addrLow;
	unsigned short selector; //code segment
	unsigned char zero; //must be zero
	unsigned char flags; //0x8e for interrupt handler
	unsigned short addrHigh;
};
#pragma pack(pop)
