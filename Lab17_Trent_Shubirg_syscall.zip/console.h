#pragma once
#include "Multiboot.h"
#include "font.h"
#include "mem.h"

volatile unsigned char* framebuffer;
struct MultibootInfo* multi;
void console_init(struct MultibootInfo* m);
void console_putc( const char s);
void set_pixel(int x, int y, int r, int g, int b);
void draw_line(int x1, int y1,int x2,int y2, int r, int g, int b);
void draw_character(int x, int y, unsigned char ch);
void draw_string(int x, int y, const char* s);