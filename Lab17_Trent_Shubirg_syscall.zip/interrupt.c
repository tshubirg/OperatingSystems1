#include "kprintf.h"
#include "IDTEntry.h"
#include "GDTEntry.h"
#include "LGDT.h"
#include "interrupt.h"
#include "file.h"
#include "kprintf.h"

struct IDTEntry idt[49];

struct GDTEntry gdt[] = {
	{ 0,0,0,0,0,0 }, //zeros
	{ 0xffff, 0,0,0, 0xcf92, 0}, //data
	{ 0xffff, 0,0,0, 0xcf9a, 0}, //code
	{ 0xffff, 0,0,0, 0xcff2, 0}, //data, ring 3
	{ 0xffff, 0,0,0, 0xcffa, 0}, //code, ring 3
	{ 0,0,0,0,0,0 } //task selector
};


void table(int i, void* func){
	unsigned x = (unsigned)func;
	idt[i].addrLow = x&0xffff;
	idt[i].selector = 2 << 3;
	idt[i].zero = 0;
	idt[i].flags = 0x8e;
	idt[i].addrHigh = x>>16;
}


void haltForever(void){
	while(1){
		asm volatile("hlt" ::: "memory");
	}
}

__attribute__((__interrupt__))
	void divideByZero(struct InterruptFrame* fr){
	kprintf("Divide by zero\n");
	kprintf("\nFatal exception at eip=%x\n",fr->eip);
	haltForever();
}

__attribute__((__interrupt__))
	void debugTrap(struct InterruptFrame* fr){
	kprintf("Debug trap \n");
	kprintf("\nFatal exception at eip=%x\n",fr->eip);
	haltForever();
}

__attribute__((__interrupt__))
	void undefinedOpcode(struct InterruptFrame* fr){
	kprintf("Bad Opcode \n");
	kprintf("\nFatal exception at eip=%x\n",fr->eip);
	haltForever();
}


__attribute__((__interrupt__))
void pageFault(struct InterruptFrame* fr, unsigned code){
	kprintf("Page fault \n");
	kprintf("Fatal exception: Code=%x eip=%x\n",code,fr->eip);
	haltForever();
}

__attribute__((__interrupt__))
void protectionFault(struct InterruptFrame* fr, unsigned code){
	kprintf("Protection Fault \n");
	kprintf("Fatal exception: Code=%x eip=%x\n",code,fr->eip);
	haltForever();
}

__attribute__((__interrupt__))
	void unknownInterrupt(struct InterruptFrame* fr){
	kprintf("\nFatal exception at eip=%x\n",fr->eip);
	haltForever();
}

__attribute__((__interrupt__))
void syscallInterrupt(struct InterruptFrame* fr){
	//kprintf("made it.");
	if( fr->esp < 0x400000 || fr->esp > 0x800000-(4*4) ){
		return; //Invalid parameter. Ignore the system call.
	}
	//kprintf("made it.");
	unsigned* x = (unsigned*) fr->esp;
	syscall_handler(x);
	//kprintf("%u\n",x[0]);
	return;
}

unsigned char kernelStack[750];
unsigned ring0StackInfo[] = {0, (unsigned)(kernelStack+sizeof(kernelStack)), 1<<3};

void interrupt_init(){
	unsigned tmp = (unsigned) ring0StackInfo;
	gdt[5].limitLow = sizeof(ring0StackInfo);
	gdt[5].base0 = tmp & 0xff;
	gdt[5].base1 = (tmp>>8) & 0xff;
	gdt[5].base2 = (tmp>>16) & 0xff;
	gdt[5].flagsAndLimitHigh = 0x00e9;
	gdt[5].base3 = (tmp>>24) & 0xff;

	struct LGDT lgdt;
	lgdt.size = sizeof(gdt);
	lgdt.addr = &gdt[0];
	asm volatile( "lgdt [eax]\n"
				  "ltr bx"
				: //no outputs
				: "a"(&lgdt), //put address of gdt in eax
				  "b"( (5<<3) | 3 ) //put task register index in ebx
				: "memory" );
	
	
	struct LIDT tmp2;
	tmp2.size = sizeof(idt);
	tmp2.addr = &idt[0];
	asm volatile("lidt [eax]" : : "a"(&tmp2) : "memory" );
	
	for(int i = 0; i < 49; ++i)
    {
        switch(i)
        {
            case 0:
                table(i, divideByZero);
                break;
            case 3:
                table(i, debugTrap);
                break;           
            case 6:
                table(i, undefinedOpcode);
                break;
            case 13:
                table(i, protectionFault);
                break;
            case 14:
                table(i, pageFault);
                break;
			case 48:
				table(i, syscallInterrupt);
				idt[i].flags = 0xee;
				break;
            default:
                table(i, unknownInterrupt);
				break;
        }        
    }
	
	//kprintf("made it.");

}

void exec(const char* filename)
{
	int fd  = file_open(filename,3);
	//kprintf("%d",fd);
	file_read(fd,(void *)0x400000, sizeof(kernelStack));
	
	file_close(fd);
	
	//asm volatile("int 48" :::"memory");
	asm volatile( "mov ax,27\n" 
		"mov ds,ax\n" 
		"mov es,ax\n" 
		"mov fs,ax\n" 
		"mov gs,ax\n" 
		"push 27\n" 
		"push 0x800000\n" 
		"pushf\n" //push eflags registerBBBB1144
		"push 35\n"
		"push 0x400000\n"
		"iret"
		::: "eax","memory" );
	kprintf("We should never get here!\n");
	haltForever();
}



void  syscall_handler ( unsigned* ptr ) {

	switch( ptr [0]) 
	{
		case SYSCALL_OPEN:
		{
			// ptr [ 1 ] = filename ,  ptr [2] = flags
			//kprintf("made it.");
			//kprintf("%u",ptr[2]);
			ptr [0] = file_open ((char *)ptr[1],  ptr[2]) ;
			break ;
		}
		case SYSCALL_CLOSE:
		{
			// ptr [ 1 ] = f i l e  descriptor
			ptr[0] = file_close(ptr[1]);
			break;
		}
		case SYSCALL_WRITE:
		{
			//kprintf("made it1.");
			if(ptr[1] == 1 || ptr[1] == 2)
			{
				//kprintf("made it2.");
				char *tmp = (char*)ptr[2];
				for (int i = 0; i < ptr[3]; i++)
				{
					kprintf("%c",tmp[i]);
				}
				ptr[0] = ptr[3];
				//kprintf("made it2.");
				break;
			}
			else
			{
				//kprintf("made it3.");
				ptr[0]=file_write(ptr[1],(char*) ptr[2],ptr[3]);
				break;
			}
		}
		case SYSCALL_READ:
		{
			//kprintf("made it3.");
			//int fd = ptr[1];
			unsigned buf = ptr[2];
			unsigned count = ptr[3];
			if(buf < 0x400000 || buf > 0x800000)
			{
				ptr[0] = -1;
				break;
			}
			if( buf + count > 0x800000 ) 
			{
				ptr[0] = -2;
				break;
			}
			if( buf + count < 0x400000 ) 
			{
				ptr[0] = -3;
				break;
			}
			//kprintf("made it3.");
			
			
			 
			//kprintf("%d\n",reg);
			ptr[0] = file_read(ptr[1],(void*)ptr[2],ptr[3]);
			break;
		}
		default:
		{
			//kprintf("made it2.");
			ptr[0] = -1;
		}
	}
}













