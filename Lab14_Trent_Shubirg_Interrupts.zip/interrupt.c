#include "kprintf.h"
#include "IDTEntry.h"
#include "GDTEntry.h"
#include "LGDT.h"
#include "interrupt.h"

struct IDTEntry idt[32];

struct GDTEntry gdt[] = {
	{ 0,0,0,0,0,0 }, //zeros
	{ 0xffff, 0,0,0, 0xcf92, 0}, //data
	{ 0xffff, 0,0,0, 0xcf9a, 0} //code
};


void table(int i, void* func){
	unsigned x = (unsigned)func;
	idt[i].addrLow = x&0xffff;
	idt[i].selector = 2 << 3;
	idt[i].zero = 0;
	idt[i].flags = 0x8e;
	idt[i].addrHigh = x>>16;
}


void haltForever(void){
	while(1){
		asm volatile("hlt" ::: "memory");
	}
}

__attribute__((__interrupt__))
	void divideByZero(struct InterruptFrame* fr){
	kprintf("Divide by zero\n");
	kprintf("\nFatal exception at eip=%x\n",fr->eip);
	haltForever();
}

__attribute__((__interrupt__))
	void debugTrap(struct InterruptFrame* fr){
	kprintf("Debug trap \n");
	kprintf("\nFatal exception at eip=%x\n",fr->eip);
	haltForever();
}

__attribute__((__interrupt__))
	void undefinedOpcode(struct InterruptFrame* fr){
	kprintf("Bad Opcode \n");
	kprintf("\nFatal exception at eip=%x\n",fr->eip);
	haltForever();
}


__attribute__((__interrupt__))
void pageFault(struct InterruptFrame* fr, unsigned code){
	kprintf("Page fault \n");
	kprintf("Fatal exception: Code=%x eip=%x\n",code,fr->eip);
	haltForever();
}

__attribute__((__interrupt__))
void protectionFault(struct InterruptFrame* fr, unsigned code){
	kprintf("Protection Fault \n");
	kprintf("Fatal exception: Code=%x eip=%x\n",code,fr->eip);
	haltForever();
}

__attribute__((__interrupt__))
	void unknownInterrupt(struct InterruptFrame* fr){
	kprintf("\nFatal exception at eip=%x\n",fr->eip);
	haltForever();
}


void interrupt_init(){
	struct LGDT lgdt;
	lgdt.size = sizeof(gdt);
	lgdt.addr = &gdt[0];
	asm volatile( "lgdt [eax]" : : "a"(&lgdt) : "memory" );
	
	
	struct LIDT tmp;
	tmp.size = sizeof(idt);
	tmp.addr = &idt[0];
	asm volatile("lidt [eax]" : : "a"(&tmp) : "memory" );
	
	for(int i = 0; i < 32; ++i)
    {
        switch(i)
        {
            case 0:
                table(i, divideByZero);
                break;
            case 3:
                table(i, debugTrap);
                break;           
            case 6:
                table(i, undefinedOpcode);
                break;
            case 13:
                table(i, protectionFault);
                break;
            case 14:
                table(i, pageFault);
                break;
            default:
                table(i, unknownInterrupt);
        }        
    }
}



