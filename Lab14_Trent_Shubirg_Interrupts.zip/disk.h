#pragma once

#include "bgd.h"
#include "dire.h"
#include "inode.h"
#include "supb.h"
#define BLOCK_SIZE 4096


int disk_read_sector(unsigned sector, void* datablock);
int disk_write_sector(unsigned sector, const void* datablock);
int list_directory(int dir_inode, int indent);
void initsupb();

union U{
	char block[4096];
	struct BlockGroupDescriptor bgd[1]; //variable size; not really 1
};

void disk_read_block(unsigned blocknum, void* buffer);

int disk_read_inode(unsigned num, struct Inode* ino);



