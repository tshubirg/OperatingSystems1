
#pragma once
#ifndef _STDARG_H_
#define _STDARG_H_

#ifndef RC_INVOKED


#ifndef _VA_LIST_DEFINED
#define _VA_LIST_DEFINED
#endif

#ifndef	_VA_LIST
#define _VA_LIST
#if defined __GNUC__ && __GNUC__ >= 3
typedef __builtin_va_list va_list;
#else
typedef char* va_list;
#endif
#endif


#define __va_argsiz(t)	\
	(((sizeof(t) + sizeof(int) - 1) / sizeof(int)) * sizeof(int))


#ifdef	__GNUC__


#define va_start(ap, pN)	\
	((ap) = ((va_list) __builtin_next_arg(pN)))
#else

	
#define va_start(ap, pN)	\
	((ap) = ((va_list) (&pN) + __va_argsiz(pN)))
#endif


#define va_end(ap)	((void)0)



#define va_arg(ap, t)					\
	 (((ap) = (ap) + __va_argsiz(t)),		\
	  *((t*) (void*) ((ap) - __va_argsiz(t))))

#endif /* Not RC_INVOKED */

#endif /* not _STDARG_H_ */















//===========================================================================

/*#pragma once

#define va_start(v,l) v.x=((char*)l)+sizeof(l)

#define va_arg(v,t) (*((*t)_va_arg(&v,sizeof(t))))

#define va_end(x) 

char* _va_arg(va_list *v, unsigned size)
{
	char * temp = v->x;
	v ->x+=size;
	return tmp;
}

typedef struct va_list_
{
	
}va_list;*/