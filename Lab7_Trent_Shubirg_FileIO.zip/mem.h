#pragma once

void kmemset(void *p, char c, int n);
void cmemset(void *p, short c, int n);
void kmemcpy(void* dv,const void* s,unsigned n);
void outb(unsigned short port, unsigned char value);
void outw(unsigned short port, unsigned short value);
unsigned char inb(unsigned short port);
unsigned short inw (unsigned short port);