#pragma once
#include "Multiboot.h"

volatile unsigned char* framebuffer;
struct MultibootInfo* multi;
void console_init(struct MultibootInfo* m);
void set_pixel(int x, int y, int r, int g, int b);
void draw_line(int x1, int y1,int x2,int y2, int r, int g, int b);