#include "console.h"


void console_init(struct MultibootInfo* mbi)
{
	framebuffer = (volatile unsigned char*) (unsigned) mbi->mbiFramebufferAddress;
	multi = mbi;
}

void draw_line(int x1, int y1,int x2,int y2, int r, int g, int b)
{
	int index1,index2;
	
	if(x1 == x2)
	{
		index1 = x1;
		for(index2 = y1; index2 < y2; index2++)
		{
			set_pixel(index1,index2,r,g,b);
		}
	}
	else if(y1 == y2)
	{
		index2 = y1;
		for(index1 = x1; index1 < x2; index1++)
		{
			set_pixel(index1,index2,r,g,b);
		}
	}
}

void set_pixel(int x, int y, int r, int g, int b)
{
	volatile unsigned char* temp = framebuffer;
	temp = framebuffer+(2*x+(y*multi->mbiFramebufferPitch));
	 r >>= (8-multi->mbiFramebufferRedMask); 
	 g >>= (8-multi->mbiFramebufferGreenMask); 
	 b >>= (8-multi->mbiFramebufferBlueMask);
	
	unsigned short colorValue = (b<<multi->mbiFramebufferBluePos) | (g<<multi->mbiFramebufferGreenPos) | (r<<multi->mbiFramebufferRedPos);
	
	*(unsigned short*)temp = colorValue;
	
	
}



//int redmask = multi->mbiFramebufferRedMask, greenmask = multi->mbiFramebufferGreenMask, bluemask = multi->mbiFramebufferBlueMask;
//int bluepos = multi->mbiFramebufferBluePos, greenpos = multi->mbiFramebufferGreenPos, redpos = multi->mbiFramebufferRedPos;
