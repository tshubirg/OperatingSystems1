#include "kprintf.h"
#include "disk.h"
#include "mem.h"

int isBusy()
{
	return inb(0x1f7) & 0x80;
}


int disk_read_block(unsigned num, void* datablock)
{
    unsigned sector = num * 8;
    for(int i = 0; i < 8; ++i)
    {
        if(disk_read_sector(sector, datablock + (i * 512)) < 0)
			return -1;
        ++sector;
    }
    return 0;

}


int disk_read_sector(unsigned sector, void* datablock)
{
	while(isBusy())
		;
	//initiate a read
	outb(0x1f6,0xe0 | (sector >> 24 ));//selecting device
	outb(0x3f6,2);//turn off interrupts
	outb(0x1f2,1);
	outb(0x1f3, sector);//low 8 bits
	outb(0x1f4, sector >> 8); 
	outb(0x1f5, sector >> 16);
	
	
	outb(0x1f7,0x20);
	while(1)
	{
		while(isBusy())
		;
		if((inb(0x1f7) & 0x08))
		{
			break;
		}
		else if((inb(0x1f7) & 0x01) || (inb(0x1f7) & 0x20))
		{
			return -1;
		}
	}
	
	unsigned short* dblock = (unsigned short*) datablock;
	for(int i=0;i<256;++i)
	{
 		unsigned short d = inw(0x1f0);
		*dblock = d;
		dblock++;
	}

	
	return 0;
}



	
	

int disk_write_sector(unsigned sector, const void* datablock)
{
	while(isBusy())
		;
	short* p = (short*)datablock;//...data to write...
	
	outb(0x1f6,0xe0 | (sector >> 24 ));//selecting device
	outb(0x3f6,2);//turn off interrupts
	outb(0x1f2,1);
	outb(0x1f3, sector);//low 8 bits
	outb(0x1f4, sector >> 8);// next 8
	outb(0x1f5, sector >> 16);//next 8
	
	
	outb(0x1f7,0x30);
	while(1)
	{
		while(isBusy())
		;
		if((inb(0x1f7) & 0x08))
			break;
		else if((inb(0x1f7) & 0x01) || (inb(0x1f7) & 0x20))
			return -1;
		
	}
	
	for(int i=0;i<256;++i)
	{
		outw( 0x1f0, *p );
		p++;
	}
	outb(0x1f7,0xe7);
	return 0;
}


















