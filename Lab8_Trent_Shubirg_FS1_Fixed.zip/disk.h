#pragma once


int i;
int disk_read_sector(unsigned sector, void* datablock);
int disk_write_sector(unsigned sector, const void* datablock);

#pragma pack(push,1)
struct BlockGroupDescriptor{
unsigned block_bitmap;
unsigned inode_bitmap;
unsigned inode_table;
unsigned short free_blocks;
unsigned short free_inodes;
unsigned short used_dirs;
unsigned short pad;
char reserved[12];
};
#pragma pack(pop)

union U{
char block[4096];
struct BlockGroupDescriptor bgd[1]; //variable size; not really 1
};

int disk_read_block(unsigned sector, void* datablock);

#pragma pack(push,1) 
struct Superblock{ 
unsigned inode_count; 
unsigned block_count; 
unsigned r_block_count; 
unsigned free_block_count; 
unsigned free_inode_count; 
unsigned first_data_block; 
unsigned logical_block_size;
unsigned logical_fragment_size;
unsigned blocks_per_group;
unsigned fragments_per_group;
unsigned inodes_per_group;
unsigned mounttime;
unsigned writetime;
unsigned short mountcount;
unsigned short maxmountcount;
unsigned short magic;
unsigned short state;
unsigned short errors;
unsigned short minorrev;
unsigned lastcheck;
unsigned checktime;
unsigned creator;
unsigned revision;
unsigned short resuid;
unsigned short resgid;
unsigned first_inode;
unsigned short inode_size;
unsigned short block_group_number;
unsigned feature_compat;
unsigned feature_incompat;
unsigned feature_ro_compat;
unsigned char uuid[16];
char volname[16];
char lastmount[64];
char reserved[824];
};
#pragma pack(pop)

