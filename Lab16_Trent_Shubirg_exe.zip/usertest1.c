//usertest1.c
int main(int argc, char* argv[])
{
	asm("hlt");
	register unsigned flag asm("esi");
	flag=0x31337;
	while(flag){
	}
	//asm("hlt");
	return 0;
}