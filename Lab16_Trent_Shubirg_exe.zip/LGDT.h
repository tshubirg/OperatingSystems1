#pragma pack(push,1)
struct LGDT{
	unsigned short size;
	struct GDTEntry* addr;
};
#pragma pack(pop)
