#include "kprintf.h"
#include "IDTEntry.h"
#include "GDTEntry.h"
#include "LGDT.h"
#include "interrupt.h"
#include "file.h"

struct IDTEntry idt[32];

struct GDTEntry gdt[] = {
	{ 0,0,0,0,0,0 }, //zeros
	{ 0xffff, 0,0,0, 0xcf92, 0}, //data
	{ 0xffff, 0,0,0, 0xcf9a, 0}, //code
	{ 0xffff, 0,0,0, 0xcff2, 0}, //data, ring 3
	{ 0xffff, 0,0,0, 0xcffa, 0}, //code, ring 3
	{ 0,0,0,0,0,0 } //task selector
};


void table(int i, void* func){
	unsigned x = (unsigned)func;
	idt[i].addrLow = x&0xffff;
	idt[i].selector = 2 << 3;
	idt[i].zero = 0;
	idt[i].flags = 0x8e;
	idt[i].addrHigh = x>>16;
}


void haltForever(void){
	while(1){
		asm volatile("hlt" ::: "memory");
	}
}

__attribute__((__interrupt__))
	void divideByZero(struct InterruptFrame* fr){
	kprintf("Divide by zero\n");
	kprintf("\nFatal exception at eip=%x\n",fr->eip);
	haltForever();
}

__attribute__((__interrupt__))
	void debugTrap(struct InterruptFrame* fr){
	kprintf("Debug trap \n");
	kprintf("\nFatal exception at eip=%x\n",fr->eip);
	haltForever();
}

__attribute__((__interrupt__))
	void undefinedOpcode(struct InterruptFrame* fr){
	kprintf("Bad Opcode \n");
	kprintf("\nFatal exception at eip=%x\n",fr->eip);
	haltForever();
}


__attribute__((__interrupt__))
void pageFault(struct InterruptFrame* fr, unsigned code){
	kprintf("Page fault \n");
	kprintf("Fatal exception: Code=%x eip=%x\n",code,fr->eip);
	haltForever();
}

__attribute__((__interrupt__))
void protectionFault(struct InterruptFrame* fr, unsigned code){
	kprintf("Protection Fault \n");
	kprintf("Fatal exception: Code=%x eip=%x\n",code,fr->eip);
	haltForever();
}

__attribute__((__interrupt__))
	void unknownInterrupt(struct InterruptFrame* fr){
	kprintf("\nFatal exception at eip=%x\n",fr->eip);
	haltForever();
}

unsigned char kernelStack[500];
unsigned ring0StackInfo[] = {
	0,
	(unsigned)(kernelStack+sizeof(kernelStack)),
	1<<3
};


void interrupt_init(){
	unsigned tmp = (unsigned) ring0StackInfo;
	gdt[5].limitLow = sizeof(ring0StackInfo);
	gdt[5].base0 = tmp & 0xff;
	gdt[5].base1 = (tmp>>8) & 0xff;
	gdt[5].base2 = (tmp>>16) & 0xff;
	gdt[5].flagsAndLimitHigh = 0x00e9;
	gdt[5].base3 = (tmp>>24) & 0xff;

	struct LGDT lgdt;
	lgdt.size = sizeof(gdt);
	lgdt.addr = &gdt[0];
	asm volatile( "lgdt [eax]\n"
				  "ltr bx"
				: //no outputs
				: "a"(&lgdt), //put address of gdt in eax
				  "b"( (5<<3) | 3 ) //put task register index in ebx
				: "memory" );
	
	
	struct LIDT tmp2;
	tmp2.size = sizeof(idt);
	tmp2.addr = &idt[0];
	asm volatile("lidt [eax]" : : "a"(&tmp2) : "memory" );
	
	for(int i = 0; i < 32; ++i)
    {
        switch(i)
        {
            case 0:
                table(i, divideByZero);
                break;
            case 3:
                table(i, debugTrap);
                break;           
            case 6:
                table(i, undefinedOpcode);
                break;
            case 13:
                table(i, protectionFault);
                break;
            case 14:
                table(i, pageFault);
                break;
            default:
                table(i, unknownInterrupt);
        }        
    }
}



void exec(const char* filename)
{
	int fd  = file_open(filename,3);
	file_read(fd,(void *)0x400000, sizeof(kernelStack));
	
	file_close(fd);
	asm volatile( "mov ax,27\n" 
		"mov ds,ax\n" 
		"mov es,ax\n" 
		"mov fs,ax\n" 
		"mov gs,ax\n" 
		"push 27\n" 
		"push 0x800000\n" 
		"pushf\n" //push eflags register
		"push 35\n"
		"push 0x400000\n"
		"iret"
		::: "eax","memory" );
	kprintf("We should never get here!\n");
	haltForever();
}



















