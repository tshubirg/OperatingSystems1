#include "mem.h"
#include "errno.h"
#include "inode.h"
#include "disk.h"
#include "kprintf.h"

#define MAX_FILES 250

struct File
{
	int in_use; //boolean if its open
	int flags;
	int offset;
	struct Inode ino;
};

char  buffer[4096];
char  some_buffer[4096];
unsigned int  U[1024];
struct Inode ino1;
struct DirEntry* d;

struct File file_table[MAX_FILES];

unsigned kstrlen(char*s)
{
	unsigned l = 0;
	while (*s != 0)
	{
		s++;
		l++;
	}
	return l;
}

int file_read(int fd, void* buf, int count)
{
	
	unsigned endPadding = 0;
	if(!(fd >= 0 && fd < MAX_FILES))
		return -EINVAL;
	struct File* fp = &file_table[fd];

	if(!(fp->in_use))
		return -EINVAL;
	
	if(count <= 0) 
		return 0;
	if(fp->offset >= fp->ino.size) 
		return 0;
	
	
	unsigned bi = fp->offset / BLOCK_SIZE;
	if(bi < 12)
		disk_read_block( fp->ino.direct[bi] , some_buffer);
	else
	{
		bi -=12;
		if(bi < 1024)
		{
			disk_read_block(fp->ino.indirect,U);
			disk_read_block( U[bi] , some_buffer);
		}
		else
		{
			bi -= 1024;
			if(bi < 1024*1024)
			{
				
				disk_read_block(fp->ino.doubleindirect,U);
				disk_read_block(U[bi >> 10],U);
				disk_read_block(U[bi % 1024],some_buffer);				
			}
			else
			{
				kprintf("File too large.");
				return-1;
			}
		}
		
	}
	unsigned bo = fp->offset % BLOCK_SIZE;
	unsigned remaining = count;
	
	if(BLOCK_SIZE-bo < remaining )
		remaining = BLOCK_SIZE-bo;
	//kprintf("1:%u\t", remaining);
	for(int i = 0; i < BLOCK_SIZE-1; i++)
	{
		if(some_buffer[i] == 0)
			endPadding++;
	}
	
	if((BLOCK_SIZE-endPadding-bo-1) < remaining && (BLOCK_SIZE-endPadding-bo-1) >0)
		remaining = (BLOCK_SIZE-endPadding-bo-1);
	//kprintf("2:%u\t", remaining);
	
	kmemcpy(buf, some_buffer + bo ,remaining);
	fp->offset += remaining;
	
	
	//kprintf("3:%u\t", remaining);
	return remaining;
}

int file_write(int fd, const void* buffer, int count){
	return -ENOSYS; //no such system call
}

int file_seek(int fd, int offs, int whence)
{
	
	if(!(fd >= 0 && fd <= MAX_FILES))
		return -EINVAL;
	
	struct File* fp = &file_table[fd];
	if(whence == 0)//seek set
	{
		//kprintf("made it.");
		if(offs < 0)
			return -EINVAL;
		else
			fp->offset = offs;
		
	}
	if(whence == 1)//seek cur
	{
		if((fp->offset + offs) < 0)
			return -EINVAL;
		else
			fp->offset += offs;
		
	}
	if(whence == 2)//seek end
	{
		if(offs + fp->ino.size < 0)
			return -EINVAL;
		else 
			fp->offset = fp->ino.size + offs;
		
	}
	return fp->offset;
}

int file_close(int fd)
{
	if(file_table[fd].in_use == 0)
		return -EINVAL;
	file_table[fd].in_use = 0;
		return 0;
}

int file_open(const char* filename, int flags)
{
	struct DirEntry* e;
	int fd = 0;
	
	for(int i = 0; i <= MAX_FILES; i++)
	{
		if(i == MAX_FILES)
			return -EMFILE;
		if(file_table[i].in_use == 0)
		{
			fd = i;
			break;
		}	
	}
	
	unsigned fnl = kstrlen((void*)filename);
	disk_read_inode(2, &ino1);
	disk_read_block(ino1.direct[0],buffer);
	char* c  = buffer;
	
	while(1)
	{
		e = (struct DirEntry*) c;
		if(e->name_len == fnl && kmemcmp((void*)e->name,(void*)filename,fnl) == 0)
		{
			file_table[fd].in_use=1;
			file_table[fd].offset = 0;
			file_table[fd].flags = flags;
			disk_read_inode(e->inode,&file_table[fd].ino);
			//kprintf("made it.");
			return fd;
		}
		if(e->name_len == 0)
			break;
		c +=  e->rec_len;
		
	}
	return -ENOENT;
	
}



