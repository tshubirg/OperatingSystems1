#include "mem.h"
#include "errno.h"
#include "inode.h"
#include "disk.h"

struct File
{
	int in_use; //boolean if its open
	struct Inode ino;
};

char  buffer[4096];
struct Inode ino;
struct DirEntry* d;

#define MAX_FILES 200

struct File file_table[MAX_FILES];

unsigned kstrlen(char*s)
{
	unsigned l = 0;
	while (*s != 0)
	{
		s++;
		l++;
	}
	return l;
}



int file_close(int fd)
{
	if(file_table[fd].in_use == 0)
		return EINVAL;
	file_table[fd].in_use = 0;
		return 0;
}

int file_open(const char* filename, int flags)
{
	struct DirEntry* e;
	int fd = 0;
	if(file_table[MAX_FILES-1].in_use == 1)
		return EMFILE;
	for(int i = 0; i < MAX_FILES; i++)
	{
		if(file_table[i].in_use == 0)
		{
			fd = i;
			break;
		}
	}
	
	unsigned fnl = kstrlen((void*)filename);
	disk_read_inode(2, &ino);
	disk_read_block(ino.direct[0],buffer);
	char* c  = buffer;
	
	while(1)
	{
		e = (struct DirEntry*) c;
		if(e->name_len == fnl && kmemcmp((void*)e->name,(void*)filename,fnl) == 0)
		{
			file_table[fd].in_use=1;
			disk_read_inode(e->inode,&file_table[fd].ino);
			return fd;
		}
		if(e->name_len == 0)
			break;
		c +=  e->rec_len;
		
	}
	return ENOENT;
	
}



