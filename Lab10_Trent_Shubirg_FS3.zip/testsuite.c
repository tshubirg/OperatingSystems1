#include "disk.h"


/*const char* decl = 
"IN CONGRESS, July 4, 1776.\n\n"
"The unanimous Declaration of the thirteen united States of America,\n\n"
"When in the Course of human events, it becomes necessary for one people to "
"dissolve the political bands which have connected them with another, "
"and to assume among the powers of the earth, the separate and equal station to "
"to which the Laws of Nature and of Nature's God entitle them, a decent "
"respect to the opinions of mankind requires that they should declare the "
"causes which impel them to the separation. \n\n"
"We hold these truths to be self-evident, that all men are created equal, "
"that they are endowed by their Creator with certain unalienable Rights, that "
"among these are Life, Liberty and the pursuit of Happiness. \n"
"\t--That to secure these rights, Governments are instituted among Men,\n"
" \t--That whenever any Form of Government becomes destructive of these "
"ends, it is the Right of the\t\tPeople\t\tto alter or to abolish it, and to "
"institute new Government, laying its foundation on such principles and "
"organizing its powers in such form, as to them shall seem most likely to "
"effect their Safety and Happiness.\n"
"\n"
"Prudence, indeed, will dictate that Governments long established should not "
"be changed for light and transient causes;and accordingly all experience hath"
"shewn, that mankind are more disposed to suffer, while evils are sufferable, "
"than to right themselves by abolishing the forms to which they are "
"accustomed. But when a long train of abuses and usurpations, pursuing "
"invariably the same Object evinces a design to reduce them under absolute Despotism, "
"it is their right, it is their duty, to throw off such Government,  "
"and to provide new Guards for their future security.\n"
"   \t--Such has been the patient sufferance of these Colonies; and such is now the "
"necessity which constrains them to alter their former Systems of Government. "
"The history of the present King of Great Britain is a history of repeated injuries "
"and usurpations, all having in direct object the establishment of an absolute Tyranny "
"over these States. To prove this, let Facts be submitted to a candid world.\n"
"...\n"
"In every stage of these Oppressions We have Petitioned for Redress in the most "
"humble terms: Our repeated Petitions have been answered only by repeated injury. "
"A Prince whose character is thus marked by every act which may define a Tyrant, "
"is unfit to be the ruler of a free people.\n"
"Nor have We been wanting in attentions to our Brittish brethren. We have warned them "
"from time to time of attempts by their legislature to extend an unwarrantable jurisdiction "
"over us. We have reminded them of the circumstances of our emigration and settlement "
"here. We have appealed to their native justice and magnanimity, and we have conjured "
"them by the ties of our common kindred to disavow these usurpations, which, would "
"inevitably interrupt our connections and correspondence. They too have been deaf "
"to the voice of justice and of consanguinity. \nWe m\bmu\bus\bst\bt, therefore, acquiesce in the "
"necessity, which denounces our Separation, and hold them, as we hold the rest of mankind, "
"Enemies in War, in Peace Friends.\n"
"We, therefore, the Representatives of the united States of America, in General Congress, "
"Assembled, appealing to the Supreme Judge of the world for the rectitude of our intentions, "
"do, in the Name, and by Authority of the good People of these Colonies, solemnly "
"publish and declare, That these \tUnited Colonies \t\tare, and of Right ought to be Free and "
"Independent States; that they are Absolved from all Allegiance to the British Crown, "
"and that all political connection between them and the State of Great Britain, "
"is and ought to be totally dissolved; and that as Free and Independent States, "
"they have full Power to levy War, conclude Peace, contract Alliances, establish Commerce, "
"and to do all other Acts and Things which Independent States may of right do. "
"And for the support of this Declaration, with a firm reliance on the protection of "
"divine Providence, we mutually pledge to each other our Lives, our Fortunes and our sacred Honor.\n"
"fooby dooby doo...";

void sweet(){
    kprintf("%s",decl);
    kprintf("\r%d %d %d %d %d%c%d...",42,43,44,45,46,127,47);
}


*/



/*const char* decl = 
"IN CONGRESS, July 4, 1776.\n\n"
"The unanimous Declaration of the thirteen united States of America,\n\n"
"When in the Course of human events, it becomes necessary for one people to "
"dissolve the political bands which have connected them with another, "
"and to assume among the powers of the earth, the separate and equal station to "
"to which the Laws of Nature and of Nature's God entitle them, a decent "
"respect to the opinions of mankind requires that they should declare the "
"causes which impel them to the separation. \n\n"
"We hold these truths to be self-evident, that all men are created equal, "
"that they are endowed by their Creator with certain unalienable Rights, that "
"among these are Life, Liberty and the pursuit of Happiness. \n"
"\t--That to secure these rights, Governments are instituted among Men,\n"
" \t--That whenever any Form of Government becomes destructive of these "
"ends, it is the Right of the\t\tPeople\t\tto alter or to abolish it, and to "
"institute new Government, laying its foundation on such principles and "
"organizing its powers in such form, as to them shall seem most likely to "
"effect their Safety and Happiness.\n";*/

//char decl2[512];



    /*int i;

    for(i=0;i<512;++i)
        decl2[i] = 'A';
        
    disk_write_sector( 4, decl+512);
    disk_write_sector( 2,decl);
    disk_write_sector( 3,decl2);
    
    disk_read_sector( 2, decl2);
	
    for(i=0;i<512;++i){
		
        if( decl[i] != decl2[i] ){
            kprintf("Bad\n");
            return;
        }
    }
    disk_read_sector( 3, decl2);
    for(i=0;i<512;++i){
        if( decl2[i] != 'A' ){
            kprintf("Badder\n");
            return;
        }
    }
    disk_read_sector( 4, decl2);
    for(i=0;i<512;++i){
        if( decl[512+i] != decl2[i] ){
            kprintf("Baddest\n");
            return;
        }
    }
            
    kprintf("Muy bien\n");*/

	
	/*struct Superblock supb;
	disk_read_sector(2, &supb);
    disk_read_sector(3, ((char*)&supb) + 512);
	kprintf("Volume label: %s  Free: %u\nBlocks per group: %u  Total blocks: %u\n",
		supb.volname, supb.free_block_count, supb.blocks_per_group, supb.block_count);
	
	static union U tmp;
	for(int i1 = 0; i1 < 3;++i1)
	{
		kprintf("Reading BGDT from group %d\n", i1);
		
		for(int i2 = 0; i2 < 3;++i2)
		{
			disk_read_block((supb.blocks_per_group * i2) + 1,&tmp.block);
			kprintf("Group %d: Free blocks = %u\n",i2,tmp.bgd->free_blocks);
		}
	}*/
	


#include "errno.h"
#include "kprintf.h"

extern int file_open(const char* fname, int flags);
extern int file_close(int fd);

void sweet(){
    int i;
    char tmp[32];
    int fd;

    const char* nonexist[] = {
        "blargh", "blargleblargleboom", 
        "blargleblargleboom.burpblah", "b.burpblah",
        "b.b", "art.txt","article1234.txt",
        "ARTICLE2.TXT",
        "article1.T","article1txt",0};
            
    for(i=0; nonexist[i] ; ++i){
        fd = file_open( nonexist[i], 0);
        if( fd >= 0 ){
            kprintf("Opened nonexistent file %s\n",nonexist[i]);
            return;
        }
    }

    for(i=-4;i<10;++i){
        if( file_close(i) == 0 ){
            kprintf("Closed nonopen %d\n",i);
            return;
        }
    }
    
    int used[6];
    for(i=0;i<6;++i)
        used[i] = -1;
    int j;
    for(i=1;i<=6;++i){
        ksprintf(tmp,"article%d.txt",i);
        fd = file_open(tmp,0);
        if(fd < 0 ){
            kprintf("Could not open %s\n",tmp);
            return;
        }
        for(j=0;j<6;++j){
            if( used[j] == fd ){
                kprintf("%d\t%d\n", used[j], fd);
                kprintf("Duplicate fd\n");
                return;
            }
        }
        used[i-1]=fd;
    }

    for(i=0;i<6;++i){
        if( file_close(used[i]) != SUCCESS ){
            kprintf("Could not close %d\n",used[i]);
            return ;
        }
    }
    
    //exhaustion test
    for(i=0;i<100000;++i){
        file_open("article1.txt",0);
    }
    fd = file_open("article1.txt",0);
    if(fd >= 0 )
        kprintf("Exhaustion test failed\n");
        
    kprintf("All OK");
}












