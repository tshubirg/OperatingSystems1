
#pragma once

int file_close(int fd);
int file_open(const char* filename, int flags);